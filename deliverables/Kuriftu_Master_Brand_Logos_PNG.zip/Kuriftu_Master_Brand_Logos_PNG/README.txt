KURIFTU RESORTS & SPA: MASTER BRAND LOGO SET (PNG)
==================================================
Source: Kuriftu Master Identity (kuriftu-master-identity.vercel.app), October 2026, "For Approval".
All artwork is rendered directly from the approved vector master. Nothing has been redrawn or traced.

CONTENTS
--------
01_Primary_Full_Lockup      Mark + KURIFTU + RESORTS. The default. Use first, wherever there is room.
02_Secondary_Horizontal     For wide, low spaces: headers, fascia boards, email signature, website bar.
03_Stacked_Heritage_Line    With "Serving since 2002". For formal and square formats.
04_Emblem_Seal              Gifting, amenities, stamps.
05_Signature_Line           Mark with the brand line "Timeless hospitality. Held by nature."
06_Brand_Mark               The Kuriftu Lady (the Heirloom) on her own. Use only once the name is already known.
07_Small_Size_Mark          Simplified mark for 6 to 12 mm (print) / 32 to 80 px (screen). Never use above 12 mm.
08_App_Icon_Favicon         Small-size mark on Paper, Kuriftu Olive and Dark Terracotta. 16 to 1024 px squares.

Each logo folder contains:
  Transparent/    Full Colour and White, trimmed tight. 1000 / 2000 / 4000 px on the long edge
                  (Small-Size Mark: 256 / 512 / 1024 px).
  On_Background/  Built with the required clear space:
                    Full Colour on Paper, White on Kuriftu Olive, White on Dark Terracotta.

Use Full Colour on light grounds (Paper, Light Grey, white).
Use White on Kuriftu Olive, Dark Terracotta, Deep Earth, Deep Green or calm photography.

COLOURS
-------
Kuriftu Gold      #AE8A4E   RGB 174 138 78    CMYK 0 21 55 32   Pantone 132 C   (the mark)
Kuriftu Olive     #6D6B54   RGB 109 107 84    CMYK 0 2 23 57    Pantone 404 C   (KURIFTU name)
Descriptor grey   #666666   (RESORTS, under review: open item (a))
Paper             #EDE7DC   RGB 237 231 220   CMYK 0 3 7 7      Pantone 7527 C
Dark Terracotta   #7A2A1B   RGB 122 42 27
Gold on light grounds is approved for the mark only. Gold never carries reading text.

CLEAR SPACE
-----------
Lockups: x = cap height of KURIFTU on all sides. Mark alone: x = 1/4 of mark width.
Nothing enters the clear space. On photography, the area behind the logo must be calm.

MINIMUM SIZES (mark height; proposed, confirm with a supplier proof)
-----------------------------------------------------------------------------
Medium                      Master mark   Small-size mark   White master
Print, offset and digital   12 mm         6 mm              20 mm
Screen                      80 px         32 px             150 px
Embroidery                  55 mm         28 mm             use positive thread
Foil and emboss             16 mm         9 mm              30 mm

DO NOT
------
Redraw, retype, stretch, rotate, outline or add effects. Do not recolour the mark or individual dots.
Do not place the mark on the terracotta gradient behind small logos. Do not use accent colours on the logo.

NOTES
-----
- The White versions of 02 to 05 use the designer's white Heirloom artwork (keyline construction),
  placed exactly as in the approved white primary lockup. They are not a simple recolour of the gold mark.
- Signature Line: the tagline lockups are flagged "conflict" in the scope. Confirm before wide use.
- The Amharic logo is a study for proofing and is not included.
- PNG files are for screen, office and general use. Use the vector master artwork for print production,
  signage, embroidery and fabrication.
